from flask import Flask, request, jsonify
import numpy as np
import pickle
import pandas as pd
from sklearn.linear_model import LogisticRegression



app = Flask(__name__)

# Load the trained logistic regression model
bankruptcy_csv= pd.read_csv('bankruptcy_csv1.csv')
X = bankruptcy_csv.iloc[:,0:6]
Y = bankruptcy_csv.iloc[:,-1]
model = LogisticRegression()
model.fit(X,Y)

# Define a function to preprocess input data
def preprocess_data(data):
    # Convert data to numpy array and reshape for model input
    return np.array(data).reshape(1, -1)

@app.route('/')
def home():
    return open('index.html').read()

@app.route('/predict', methods=['POST'])
def predict():
    # Get input data from request
    data = request.get_json()

    # Preprocess input data
    input_data = preprocess_data([data['industrial_risk'], data['management_risk'], data['financial_flexibility'], 
                                  data['credibility'], data['competitiveness'], data['operating_risk']])

    # Predict bankruptcy probability
    bankruptcy_probability = model.predict(input_data)[0]
    

  
    # Return prediction result
    return jsonify({'prediction': bankruptcy_probability})

if __name__ == '__main__':
    app.run(debug=True)
